#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

#include <QComboBox>
#include <QFontComboBox>
#include <QColorDialog>
#include <QFile>
#include <QFileDialog>
#include <QFontDialog>
#include <QTextCursor>
#include <QTextStream>
#include <QTextDocumentWriter>
#include <QMessageBox>
#include <QPixmap>
#include <QPrinter>
#include <QPrintDialog>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_actionNew_triggered();

    void on_actionOpen_triggered();

    bool on_actionSave_triggered();

    void on_actionCopy_triggered();

    void on_actionPrint_triggered();

    void on_actionExit_triggered();

    void on_actionCut_triggered();

    void on_actionPaste_triggered();

    void on_actionZoom_In_triggered();

    void on_actionZoom_Out_triggered();

    void on_actionAbout_triggered();

    void on_actionBold_triggered();

    void on_actionItalic_triggered();

    void on_actionUnderline_triggered();

    void on_actionFont_triggered();

    void on_actionColor_triggered();
    bool on_actionSave_2_triggered();

private:
    bool maybeSave();
    bool fileSave();

private:
    Ui::MainWindow *ui;
    QString currentFileName = "";
};
#endif // MAINWINDOW_H
