﻿#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->setCentralWidget(ui->textEdit);

    QPixmap colorpix(16, 16);
    colorpix.fill(Qt::black);
    ui->actionColor->setIcon(colorpix);
    ui->textEdit->setTextColor(Qt::black);

    QFont defaultFont("Times", 10, QFont::Normal);
    ui->textEdit->setFont(defaultFont);

    statusBar()->showMessage("Ready");
}

MainWindow::~MainWindow()
{
    maybeSave();
    delete ui;
}

bool MainWindow::maybeSave()
{
    if (!ui->textEdit->document()->isModified())
        return true;

    const QMessageBox::StandardButton ret =
        QMessageBox::warning(this, QCoreApplication::applicationName(),
                             tr("The document has been modified.\n"
                                "Do you want to save your changes?"),
                             QMessageBox::Save | QMessageBox::Discard | QMessageBox::Cancel);
    if (ret == QMessageBox::Save)
        return on_actionSave_2_triggered();
    else if (ret == QMessageBox::Cancel)
        return false;
    return true;
}


void MainWindow::on_actionNew_triggered()
{
    maybeSave();
    currentFileName.clear();
    ui->textEdit->setText(QString());
    QPixmap colorpix(16, 16);
    colorpix.fill(Qt::black);
    ui->actionColor->setIcon(colorpix);
    ui->textEdit->setTextColor(Qt::black);
    QFont defaultFont("Times", 10, QFont::Normal);
    ui->textEdit->setFont(defaultFont);
    ui->actionBold->setChecked(false);
    ui->actionItalic->setChecked(false);
    ui->actionUnderline->setChecked(false);
    statusBar()->showMessage("Ready");
}

void MainWindow::on_actionOpen_triggered()
{
    QFileDialog fileDialog(this);
    fileDialog.setWindowTitle("Open...");
    fileDialog.setAcceptMode(QFileDialog::AcceptMode::AcceptOpen);

    fileDialog.setNameFilter("Riley Text (*.rtxt)");

    int response = fileDialog.exec();

    if(response != QDialog::Accepted) {
        QMessageBox::warning(this, "Error", "No file selected.");
        return;
    }

    QString fileName = fileDialog.selectedFiles().at(0);
    QFile file(fileName);

    if(!file.open(QFile::ReadOnly | QFile::Text)){
        QMessageBox::warning(this, "Warning", "Cannot open file : " + file.errorString());
        return;
    }
    currentFileName = fileName;
    setWindowTitle(fileName);
    QTextStream in(&file);
    QString text = in.readAll();
    maybeSave();
    ui->textEdit->setText(text);
    file.close();
}

bool MainWindow::on_actionSave_2_triggered() // Save
{
    if (currentFileName.isEmpty())
        return on_actionSave_triggered();
    if (currentFileName.startsWith(QStringLiteral(":/")))
        return on_actionSave_triggered();

    QFile file(currentFileName);
    if (file.open(QFile::WriteOnly | QFile::Text)) {
        ui->textEdit->document()->setModified(false);
        statusBar()->showMessage(tr("Wrote \"%1\"").arg(QDir::toNativeSeparators(currentFileName)));
    } else {
        statusBar()->showMessage(tr("Could not write to file \"%1\"")
                                 .arg(QDir::toNativeSeparators(currentFileName)));
    }
    setWindowTitle(currentFileName);
    QTextStream out(&file);
    QString text = ui->textEdit->toHtml();
    out << text;
    file.close();
    return true;
}

bool MainWindow::on_actionSave_triggered() // Save As
{
    QFileDialog fileDialog(this);
    fileDialog.setWindowTitle("Save...");
    fileDialog.setAcceptMode(QFileDialog::AcceptMode::AcceptSave);

    fileDialog.setNameFilter("Riley Text (*.rtxt)");

    int response = fileDialog.exec();

    if(response != QDialog::Accepted) {
        QMessageBox::warning(this, "Error", "No file selected.");
        return false;
    }

    QString fileName = fileDialog.selectedFiles().at(0);
    QFile file(fileName);

    if(!file.open(QFile::WriteOnly | QFile::Text)){
        QMessageBox::warning(this, "Warning", "Cannot save file : " + file.errorString());
        return false;
    }
    currentFileName = fileName;
    setWindowTitle(fileName);
    QTextStream out(&file);
    QString text = ui->textEdit->toHtml();
    out << text;
    file.close();
    return true;
}

void MainWindow::on_actionCopy_triggered()
{
    ui->textEdit->copy();
}

void MainWindow::on_actionCut_triggered()
{
    ui->textEdit->cut();
}

void MainWindow::on_actionPaste_triggered()
{
    ui->textEdit->paste();
}

void MainWindow::on_actionPrint_triggered()
{
    QPrinter printer;
    printer.setPrinterName("Printer Name");
    QPrintDialog pDialog(&printer, this);
    if(pDialog.exec() == QDialog::Rejected){
        QMessageBox::warning(this, "Warning", "Cannot Access printer");
        return;
    }
    ui->textEdit->print(&printer);
}

void MainWindow::on_actionExit_triggered()
{
    maybeSave();
    QApplication::quit();
}

void MainWindow::on_actionZoom_In_triggered()
{
    ui->textEdit->zoomIn();
}

void MainWindow::on_actionZoom_Out_triggered()
{
    ui->textEdit->zoomOut();
}

void MainWindow::on_actionAbout_triggered()
{
    QMessageBox::information(this, "About", "Designed By Riley Maranville" "\nDesigned Using Qt" "\nCS321" "\nText Editor Project");
}

void MainWindow::on_actionBold_triggered()
{
    if (ui->actionBold->isChecked())
        ui->textEdit->setFontWeight(QFont::Bold);
    else
        ui->textEdit->setFontWeight(QFont::Normal);
}

void MainWindow::on_actionItalic_triggered()
{
    if (ui->actionItalic->isChecked())
        ui->textEdit->setFontItalic(true);
    else
        ui->textEdit->setFontItalic(false);
}

void MainWindow::on_actionUnderline_triggered()
{
    if (ui->actionUnderline->isChecked())
        ui->textEdit->setFontUnderline(true);
    else
        ui->textEdit->setFontUnderline(false);
}

void MainWindow::on_actionFont_triggered()
{
    ui->textEdit->setCurrentFont(QFontDialog::getFont(0, ui->textEdit->font(), this, "Font Selection..."));
}

void MainWindow::on_actionColor_triggered()
{
    QColor color = QColorDialog().getColor();
    ui->textEdit->setTextColor(color);

    QPixmap colorpix(16,16);
    colorpix.fill(color);
    ui->actionColor->setIcon(colorpix);
}
